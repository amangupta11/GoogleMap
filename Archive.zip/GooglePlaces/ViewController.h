//
//  ViewController.h
//  GooglePlaces
//
//  Created by Aman Gupta on 25/11/15.
//  Copyright © 2015 Aman Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import<GoogleMaps/GoogleMaps.h>
#import <CoreLocation/CoreLocation.h>
@interface ViewController : UIViewController<CLLocationManagerDelegate, GMSMapViewDelegate>
{
    GMSMapView * mapView;
    CLLocation *currentLocation;
    CLLocationManager *locationManager;
    NSMutableArray *_coordinates;
    GMSPolyline *_polyline;
    GMSMarker *_markerStart;
    GMSMarker *_markerFinish;
}
@property (nonatomic, strong) CLLocationManager *locationManager;
@property (strong, nonatomic) IBOutlet GMSMapView *mapView;

@end

