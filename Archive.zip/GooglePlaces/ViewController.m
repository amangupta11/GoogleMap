//
//  ViewController.m
//  GooglePlaces
//
//  Created by Aman Gupta on 25/11/15.
//  Copyright © 2015 Aman Gupta. All rights reserved.
//

#import "ViewController.h"
#import<GoogleMaps/GoogleMaps.h>
#import <CoreLocation/CoreLocation.h>
@interface ViewController ()<UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *sourceAddress;

@property (strong, nonatomic) IBOutlet UITextField *destinationAddress;


@end

@implementation ViewController
@synthesize locationManager;
@synthesize mapView, sourceAddress, destinationAddress;
CLPlacemark *thePlacemark;
CLLocationCoordinate2D Source;
CLLocationCoordinate2D Destination;
GMSPolyline *polyline = nil;
CLLocation *startLocation;
CLLocation *newSourceLocation;
GMSMarker *destinationMarker;
GMSMarker *startMarker;
CLLocation *endLocation;
bool currentLocationEnable = true;
- (void)viewDidLoad {
    [super viewDidLoad];
    self.locationManager = [[CLLocationManager alloc] init];
    
    [[self locationManager] setDelegate:self];
    if ([self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        if([CLLocationManager authorizationStatus]== kCLAuthorizationStatusAuthorizedWhenInUse){
             mapView.myLocationEnabled = YES;
        }
        else{
            [self.locationManager requestWhenInUseAuthorization];
        }
    }
    [[self locationManager] setDesiredAccuracy:kCLLocationAccuracyBest];
    [[self locationManager] startUpdatingLocation];
     _coordinates = [NSMutableArray new];
    
    mapView.myLocationEnabled = YES;
    self.mapView.accessibilityElementsHidden = NO;
    self.mapView.settings.scrollGestures = YES;
    self.mapView.settings.zoomGestures = YES;
    self.mapView.settings.compassButton = YES;
    self.mapView.settings.myLocationButton = YES;
    //self.mapView.mapType = kGMSTypeHybrid;
    self.sourceAddress.delegate = self;
    self.destinationAddress.delegate = self;
    self.mapView.delegate = self;
  
    sourceAddress.textColor = [UIColor lightGrayColor];
  }
-(void) locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
    currentLocation = locations.lastObject;
    [self getCurrentLocation];
    [[self locationManager] stopUpdatingLocation];
}

-(void)getCurrentLocation
{
    startLocation = [[CLLocation alloc] initWithLatitude:currentLocation.coordinate.latitude longitude:currentLocation.coordinate.longitude];
    [_coordinates addObject:startLocation];
    
    mapView.myLocationEnabled = YES;
    GMSMarker *mkr= [[GMSMarker alloc]init];
     mkr.icon =[GMSMarker markerImageWithColor:[UIColor greenColor]];
    [mkr setPosition:[[_coordinates objectAtIndex:0] coordinate]];
    CLGeocoder * geoCoder = [[CLGeocoder alloc] init];
    [geoCoder reverseGeocodeLocation: locationManager.location completionHandler:
     ^(NSArray *placemarks, NSError *error) {
         CLPlacemark *placemark = [placemarks objectAtIndex:0];
         [mkr setTitle:placemark.name];
         sourceAddress.text = @"Current Location";
     }];
    //[mkr setIcon:[UIImage imageNamed:@"CAb.jpeg"]];
    [mkr setMap:mapView];
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:currentLocation.coordinate.latitude
                                                            longitude:currentLocation.coordinate.longitude
                                                                 zoom:6];
    [mapView setCamera:camera];

    
}
-(void)getCoordinates{
    if(currentLocationEnable == true)
    {
         Source = CLLocationCoordinate2DMake(startLocation.coordinate.latitude, startLocation.coordinate.longitude);
    }
    else
    {
         Source = CLLocationCoordinate2DMake(newSourceLocation.coordinate.latitude, newSourceLocation.coordinate.longitude);
        
    }
   
    Destination = CLLocationCoordinate2DMake(endLocation.coordinate.latitude, endLocation.coordinate.longitude);
    GMSCoordinateBounds *bounds =  [[GMSCoordinateBounds alloc]  initWithCoordinate:Source coordinate:Destination];
    bounds = [bounds includingCoordinate:Source];
    bounds = [bounds includingCoordinate:Destination];
    GMSCameraUpdate *update = [GMSCameraUpdate fitBounds:bounds withPadding:15];
    [mapView animateWithCameraUpdate:update];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)GetRoute:(id)sender {
   
    _coordinates = [NSMutableArray new];
    if((![sourceAddress.text isEqual:@""] && ![destinationAddress.text isEqual:@""]))
    {
        if(currentLocationEnable == true && (startLocation && endLocation!= nil))
        {
        polyline.map = nil;
        [self drawPathFrom:startLocation toDestination:endLocation];
        }
        else if(currentLocationEnable == false && (newSourceLocation && endLocation!= nil))
        {
        polyline.map = nil;
         [self drawPathFrom:newSourceLocation toDestination:endLocation];
        }
        else{
            UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Enter Correct Place"
                                                              message:@""
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles:nil];
            
            [message show];
        }
    }
    else{
        if([sourceAddress.text isEqual:@""])
        {
            UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Enter Source"
                                                              message:@""
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles:nil];
            
            [message show];
        }
        else{
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Enter Destination"
                                                          message:@""
                                                         delegate:nil
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        
        [message show];
        }
    }
}
-(void)drawPathFrom:(CLLocation*)source toDestination:(CLLocation*)destination{
    NSString *baseUrl = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/directions/json?origin=%f,%f&destination=%f,%f&sensor=true&mode=driving", source.coordinate.latitude,  source.coordinate.longitude, destination.coordinate.latitude,  destination.coordinate.longitude];
    
    NSURL *url = [NSURL URLWithString:[baseUrl stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    
    NSLog(@"Url: %@", url);
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
        
        GMSMutablePath *path = [GMSMutablePath path];
        
        NSError *error = nil;
        NSDictionary *result = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        
        NSArray *routes = [result objectForKey:@"routes"];
        
        NSDictionary *firstRoute = [routes objectAtIndex:0];
        
        NSDictionary *leg =  [[firstRoute objectForKey:@"legs"] objectAtIndex:0];
        
        NSArray *steps = [leg objectForKey:@"steps"];
        
        int stepIndex = 0;
        
        CLLocationCoordinate2D stepCoordinates[1  + [steps count] + 1];
        
        for (NSDictionary *step in steps) {
            
            NSDictionary *start_location = [step objectForKey:@"start_location"];
            stepCoordinates[++stepIndex] = [self coordinateWithLocation:start_location];
            [path addCoordinate:[self coordinateWithLocation:start_location]];
            
            NSString *polyLinePoints = [[step objectForKey:@"polyline"] objectForKey:@"points"];
            GMSPath *polyLinePath = [GMSPath pathFromEncodedPath:polyLinePoints];
            for (int p=0; p<polyLinePath.count; p++) {
                [path addCoordinate:[polyLinePath coordinateAtIndex:p]];
            }
            
            
            if ([steps count] == stepIndex){
                NSDictionary *end_location = [step objectForKey:@"end_location"];
                stepCoordinates[++stepIndex] = [self coordinateWithLocation:end_location];
                [path addCoordinate:[self coordinateWithLocation:end_location]];
            }
        }
        
        polyline = [GMSPolyline polylineWithPath:path];
        polyline.strokeColor = [UIColor redColor];
        polyline.strokeWidth = 3.f;
        polyline.map = mapView;
    }];
    
}
- (CLLocationCoordinate2D)coordinateWithLocation:(NSDictionary*)location
{
    double latitude = [[location objectForKey:@"lat"] doubleValue];
    double longitude = [[location objectForKey:@"lng"] doubleValue];
    
    return CLLocationCoordinate2DMake(latitude, longitude);
}

-(void)mapView:(GMSMapView *)mapView didTapAtCoordinate:(CLLocationCoordinate2D)coordinate
{
    startMarker.map = nil;
    polyline.map = nil;
    currentLocationEnable = false;
    CLLocationCoordinate2D tapPosition = CLLocationCoordinate2DMake(coordinate.latitude, coordinate.longitude);
     newSourceLocation = [[CLLocation alloc] initWithLatitude:coordinate.latitude longitude:coordinate.longitude];
    startMarker = [GMSMarker markerWithPosition:tapPosition];
    startMarker.map = self.mapView;
    CLGeocoder * geoCoder = [[CLGeocoder alloc] init];
    [geoCoder reverseGeocodeLocation: newSourceLocation completionHandler:
     ^(NSArray *placemarks, NSError *error) {
         CLPlacemark *placemark = [placemarks objectAtIndex:0];
         [startMarker setTitle:placemark.name];
         sourceAddress.text = placemark.name;
         
     }];
    sourceAddress.userInteractionEnabled = true;
    sourceAddress.textColor = [UIColor blackColor];

   }
-(BOOL)didTapMyLocationButtonForMapView:(GMSMapView *)mapview
{
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:currentLocation.coordinate.latitude
                                                            longitude:currentLocation.coordinate.longitude
                                                                 zoom:15];
    [mapview setCamera:camera];
    startLocation = [[CLLocation alloc] initWithLatitude:currentLocation.coordinate.latitude longitude:currentLocation.coordinate.longitude];
    [_coordinates addObject:startLocation];
    sourceAddress.text = @"Current Location";
    sourceAddress.textColor = [UIColor lightGrayColor];
    currentLocationEnable = true;
    startMarker.map = nil;
    polyline.map = nil;
    return true;
}


- (IBAction)DestinationAddress:(UITextField *)sender {
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder geocodeAddressString:sender.text completionHandler:^(NSArray *placemarks, NSError *error) {
        if (error) {
            NSLog(@"%@", error);
            UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"No Place Found"
                                                              message:@""
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles:nil];
            
            [message show];
            endLocation = nil;
        }
        else {
            thePlacemark = placemarks.lastObject;
            CLLocation *three = [[CLLocation alloc] initWithLatitude:26.9124165 longitude:75.7872879];
            [_coordinates addObject:three];
            GMSMarker *mkr2= [[GMSMarker alloc]init];
            [mkr2 setPosition:[[_coordinates lastObject] coordinate]];
            [mkr2 setTitle:@"Jaipur"];
            [mkr2 setIcon:[UIImage imageNamed:@"CAb.jpeg"]];
            [mkr2 setMap:mapView];
            endLocation = [[CLLocation alloc] initWithLatitude:thePlacemark.location.coordinate.latitude longitude:thePlacemark.location.coordinate.longitude];
            [_coordinates addObject:endLocation];
            destinationMarker.map = nil;
            polyline.map = nil;
            destinationMarker = [[GMSMarker alloc]init];
            [destinationMarker setPosition:[[_coordinates lastObject] coordinate]];
            CLGeocoder * geoCoder = [[CLGeocoder alloc] init];
            [geoCoder reverseGeocodeLocation: endLocation completionHandler:
             ^(NSArray *placemarks, NSError *error) {
                 CLPlacemark *placemark = [placemarks objectAtIndex:0];
                 [destinationMarker setTitle:placemark.name];
             }];
            destinationMarker.icon =[GMSMarker markerImageWithColor:[UIColor blueColor]];
           // [mkr3 setIcon:[UIImage imageNamed:@"CAb.jpeg"]];
            [destinationMarker setMap:mapView];
            CLLocation *four = [[CLLocation alloc] initWithLatitude:26.8465108 longitude:80.9466832];
            [_coordinates addObject:four];
            GMSMarker *mkr4= [[GMSMarker alloc]init];
            [mkr4 setPosition:[[_coordinates lastObject] coordinate]];
            [mkr4 setTitle:@"Lucknow"];
            [mkr4 setIcon:[UIImage imageNamed:@"CAb.jpeg"]];
            [mkr4 setMap:mapView];
            CLLocation *five = [[CLLocation alloc] initWithLatitude:22.725313 longitude:75.865555];
            [_coordinates addObject:five];
            GMSMarker *mkr5= [[GMSMarker alloc]init];
            [mkr5 setPosition:[[_coordinates lastObject] coordinate]];
            [mkr5 setTitle:@"Indore"];
            [mkr5 setIcon:[UIImage imageNamed:@"CAb.jpeg"]];
            [mkr5 setMap:mapView];
           [self getCoordinates];
        }
        
    }];
}
- (IBAction)SourceAddress:(UITextField *)sender {
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder geocodeAddressString:sender.text completionHandler:^(NSArray *placemarks, NSError *error) {
        if (error) {
            NSLog(@"%@", error);
            UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"No Place Found"
                                                              message:@""
                                                             delegate:nil
                                                    cancelButtonTitle:@"OK"
                                                    otherButtonTitles:nil];
            
            [message show];
            startLocation = nil;
            newSourceLocation = nil;
        }
        else {
            thePlacemark = placemarks.lastObject;
              newSourceLocation = [[CLLocation alloc] initWithLatitude:thePlacemark.location.coordinate.latitude longitude:thePlacemark.location.coordinate.longitude];
             [_coordinates addObject:newSourceLocation];
            startMarker.map = nil;
            polyline.map = nil;
            currentLocationEnable = false;
            startMarker = [[GMSMarker alloc]init];
            [startMarker setPosition:[[_coordinates lastObject] coordinate]];
            CLGeocoder * geoCoder = [[CLGeocoder alloc] init];
            [geoCoder reverseGeocodeLocation: newSourceLocation completionHandler:
             ^(NSArray *placemarks, NSError *error) {
                 CLPlacemark *placemark = [placemarks objectAtIndex:0];
                 [startMarker setTitle:placemark.name];
             }];
            [startMarker setMap:mapView];
            GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:thePlacemark.location.coordinate.latitude
                                                                    longitude:thePlacemark.location.coordinate.longitude
                                                                         zoom:15];
            GMSCameraUpdate *cameraUpdate = [GMSCameraUpdate setCamera:camera];
            [mapView animateWithCameraUpdate:cameraUpdate];
            
        }
        
    }];
    
}
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if(textField.tag == 0)
    {
         sourceAddress.textColor = [UIColor blackColor];
    }
    else{
        
    }
    return true;
}


- (IBAction)ClearRoute:(id)sender {
    
    sourceAddress.text = nil;
    destinationAddress.text =nil;
    polyline.path = nil;
    destinationMarker.map = nil;
    startMarker.map = nil;
    
    
}


@end
