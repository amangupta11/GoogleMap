//
//  AppDelegate.h
//  GooglePlaces
//
//  Created by Aman Gupta on 25/11/15.
//  Copyright © 2015 Aman Gupta. All rights reserved.
//

#import <UIKit/UIKit.h>
#import<GoogleMaps/GoogleMaps.h>
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

